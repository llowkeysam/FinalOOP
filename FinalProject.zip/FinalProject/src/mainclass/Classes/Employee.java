/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainclass.Classes;


public class Employee extends StakeHolder {
    String username,password;
    public Employee(){
        super();
        this.username = null;
        this.password = null;
    }
    public Employee(String firstName,
            String lastName,
            String gender,
            long phoneNumber,
            String username,
            String password){
        super(firstName,lastName,gender,phoneNumber);
        this.username = username;
        this.password = password;
    }
    @Override
    public boolean login(String username,String password){
        return this.username.equals(username)&&this.password.equals(password);
    }
    @Override
    public boolean contains(String username){
        return this.username.equals(username);
    }
    @Override
    public boolean searchEmployee(String firstName,String lastName){
       return this.firstName.equals(firstName)&&this.lastName.equals(lastName);
    }
    @Override
    public String getInfo(){
        String info = super.getInfo()
                +"\nUsername: "+this.username+"\n";
        return info;
    }
}
