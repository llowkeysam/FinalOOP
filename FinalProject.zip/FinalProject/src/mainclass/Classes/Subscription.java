/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainclass.Classes;

/**
 *
 * @author Sam
 */
public class Subscription {
    Date date;
    Object[] sports;
    double totalAmount;
    Card card;
    public Subscription(){
        date = new Date();
        sports = null;
        card = new Card();
        totalAmount = 0;
    }
    public Subscription(Object[] sports,
            double totalAmount,
            Card card,
            int day,
            int month,
            int year){
        this.sports = sports;
        this.totalAmount = totalAmount;
        this.date = new Date(day,month,year);
        this.card = card;
    }
    public String getCardInfo(StakeHolder user){
        String info = this.card.getInfo(user);
        info += "\nSports :";
        for(Object s: this.sports){
            info += "\n"+s;
        }
        info = info +"\nTotal amount: "+this.totalAmount;
        return info;
    }
    public int getCardNumber(){
        return this.card.getCardNumber();
    }
    public String getSports(){
        String sport="";
        for(Object o : this.sports){
            sport += "\n"+o.toString();
        }
        return sport;
    }
    public String clientType(){
        return this.card.getType();
    }
    public boolean checkValidity(int day,int month,int year){
        return this.card.checkValidity(day,month,year);
    }
}
