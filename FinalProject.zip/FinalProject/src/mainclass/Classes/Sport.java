/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainclass.Classes;

/**
 *
 * @author Sam
 */
public class Sport {
    int id;
    int availablePlaces;
    static int idCounter = 1;
    String sportName, coachName, roomNumber;
    double subPrice;
    Object[] days;
    Object hour;
    public Sport(){
        this.id = Sport.idCounter++;
        this.roomNumber = null;
        this.availablePlaces = 0;
        this.subPrice = 0;
        this.sportName = null;
        this.coachName = null;
        this.days = null;
        this.hour = null;
    }
    public Sport(String roomNumber,
            int availablePlaces,
            double subPrice,
            String sportName,
            String coachName,
            Object[] days,
            Object hour){
        this.id = Sport.idCounter++;
        this.roomNumber = roomNumber;
        this.availablePlaces = availablePlaces;
        this.subPrice = subPrice;
        this.sportName = sportName;
        this.coachName = coachName;
        this.days = days;
        this.hour = hour;
    }
    public String getInfo(){
        String info = "Sport name: "+this.sportName
                +"\nID: "+this.id
                +"\nCoach name: "+this.coachName
                +"\nAvailable spots: "+this.availablePlaces
                +"\nDays:";
        for(Object s : this.days){
            info += "\n"+s;
        }
        info += "\nHour: "+this.hour
                +"\nSubcription Price: "+this.subPrice+"\n";
        return info;
    }
    public String getName(){
        return this.sportName;
    }
    public int getAvailableSpots(){
        return this.availablePlaces;
    }
    public boolean contains(String sportName){
        return this.sportName.equals(sportName);
    }
    public void decrementSpots(){
        this.availablePlaces--;
    }
    public double getPrice(){
        return this.subPrice;
    }
}
