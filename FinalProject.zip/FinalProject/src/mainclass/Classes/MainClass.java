/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainclass.Classes;

import java.util.ArrayList;
import mainclass.Frames.Login;

/**
 *
 * @author Sam
 */
public class MainClass {
    public static ArrayList<StakeHolder> users = new ArrayList<StakeHolder>();
    public static ArrayList<Sport> sports = new ArrayList<Sport>();
    public static void main(String[] args) {
        users.add(new Employee("Sam", "Omran", "Male", 94455, "llowkeysam", "1234"));
        users.add(new Employee("Nour", "Mouazen", "Female", 6363, "nourr", "3214"));
        Object[] days = {"Thursday","Wednesday"};
        sports.add(new Sport("cl08", 5, 500, "basket", "johnny", days, 45));
       new Login().setVisible(true);
    }
}
