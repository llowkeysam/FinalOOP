/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainclass.Classes;


public class Client extends StakeHolder {
    int age;
    double weight , height;
    Subscription subscription;
    public Client(){
        this.age = 12;
        this.height = 100;
        this.weight = 70;
        this.subscription = new Subscription();
    }
    public Client(String firstName,
            String lastName,
            String gender,
            long phoneNumber,
            int age,
            double weight,
            double height,
            int startDay,
            int startMonth,
            int startYear,
            int endDay,
            int endMonth,
            int endYear,
            int index,
            Object[] sports,
            double totalAmount){
        super(firstName,lastName,gender,phoneNumber);
        this.age = age;
        this.height = height;
        this.weight = weight;
        this.subscription = new Subscription(sports,
                totalAmount,
                new Card(startDay, startMonth, startYear, endDay, endMonth, endYear, index),
                startDay,
                startMonth,
                startYear);
    }
    @Override
    public boolean contains(String firstName,String lastName){
        return this.firstName.equals(firstName)&&this.lastName.equals(lastName);
    }
    @Override
    public String getName()
    {
        return this.firstName+" "+this.lastName;
    }
    @Override
    public String getGender(){
        return this.gender;
    }
    @Override
    public String getCardInfo(StakeHolder user){
        return this.subscription.getCardInfo(user);
    }
    @Override
    public int getCardNumber(){
        return this.subscription.getCardNumber();
    }
    @Override
    public String getInfo(){
        String info = super.getInfo();
        info = info + "\nAge: "+this.age
                +"\nWeight: "+this.weight
                +"\nHeight: "+this.height
                +"\nSports: "+this.subscription.getSports()
                +"\nClient type: "+this.subscription.clientType();
        return info;
    }
    @Override
    public boolean checkValidity(int day,int month,int year){
        return this.subscription.checkValidity(day,month,year);
    }
}
