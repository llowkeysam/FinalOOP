/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainclass.Classes;

/**
 *
 * @author Sam
 */
public class Card {
    int cardNumber;
    static int cardCounter = 1;
    Date startDate;
    Date endDate;
    String[] types = {"Normal","Silver","Gold"};
    String clientType;
    public Card(){
        this.cardNumber = Sport.idCounter++;
        this.startDate = new Date();
        this.endDate = new Date();
    }
    public Card(int startDay,
            int startMonth,
            int startYear,
            int endDay,
            int endMonth,
            int endYear,
            int index){
        this.cardNumber = Card.cardCounter++;
        this.startDate = new Date(startDay, startMonth, startYear);
        this.endDate = new Date(endDay,endMonth,endYear);
        this.clientType = this.types[index];
    }
    public String getInfo(StakeHolder user){
        String info = "Client name: "+user.getName()
                +"\nGender: "+user.getGender()
                +"\nCard number: "+this.cardNumber
                +"\nStart date: "+this.startDate.getDate()
                +"\nEnd date: "+this.endDate.getDate()
                +"\nClient type: "+this.clientType;
        return info;
    }
    public int getCardNumber(){
        return this.cardNumber;
    }
    public String getType(){
        return this.clientType;
    }
    public boolean checkValidity(int day,int month,int year){
        if(year>this.endDate.year) 
            return false;
        else{
            if(month>this.endDate.month) 
                return false;
            else{
                if(month==this.endDate.month){
                    if(day>this.endDate.day)
                        return false;
                }
            }
        }
        return true;
    }
}
