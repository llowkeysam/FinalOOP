/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainclass.Classes;

/**
 *
 * @author Sam
 */
public class Date {
    int day , month , year;
    public Date(){
        this.day = 1;
        this.month = 1;
        this.year = 2021;
    }
    public Date(int day,int month,int year){
        this.day = day;
        this.month = month;
        this.year = year;
    }
    public String getDate(){
        return this.day+"/"+this.month+"/"+this.year;
    }
}
