/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainclass.Classes;

/**
 *
 * @author Sam
 */
public class StakeHolder {
    String firstName,lastName,gender;
    long phoneNumber;
    
    public StakeHolder(){
        this.firstName = null;
        this.lastName = null;
        this.gender = null;
        this.phoneNumber = 0;
    }
    public StakeHolder(String firstName,String lastName,String gender,long phoneNumber){
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
    }
    public boolean login(String username,String password){
        return false;
    }
    public String getName(){
        return this.firstName+" "+this.lastName;
    }
    public String getGender(){
        return this.gender;
    }
    public boolean contains(String username){
        return false;
    }
    public boolean contains(String firstName,String lastName){
        return false;
    }
    public boolean searchEmployee(String firstName,String lastName){
        return false;
    }
    public String getInfo(){
        String info = "Full name: "+this.firstName+" "+this.lastName
                +"\nGender: "+this.gender
                +"\nPhone number: "+this.phoneNumber;
        return info;
    }
    public String getCardInfo(StakeHolder user){
        return "Info";
    }
    public int getCardNumber(){
        return 0;
    }
    public boolean checkValidity(int day,int month,int year){
        return false;
    }
}
